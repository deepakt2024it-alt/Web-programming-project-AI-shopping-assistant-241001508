# AI Shopping Assistant — React Starter

## Quick start (Windows)

1. Install **Node.js LTS** from https://nodejs.org/ if it is not already installed.
2. Extract this ZIP to a normal folder (do not run it from inside the ZIP).
3. Double-click **`start.bat`**.
4. On the first run, it installs the dependencies. Your browser opens at `http://127.0.0.1:5173`.
5. Keep the terminal window open while using the app. Press `Ctrl+C` to stop it.

## Alternative commands

```bash
npm install
npm run dev
```

## Project layout

- `src/` — React + Vite launcher.
- `public/legacy/` — original AI Shopping Assistant app and its assets, preserved to keep its shopping, map, and route-guidance features working.
- `start.bat` — Windows startup script with Node/npm checks and first-run dependency installation.

The React app hosts the original working application in an iframe, so the existing DOM-based map and navigation code remains intact while the project has a standard React/Vite entry point. This version runs locally and does not require a database or API key.

import React from 'react'

export default function App() {
  return (
    <main className="app-shell">
      <header className="app-header">
        <div className="brand-icon" aria-hidden="true">🛒</div>
        <div className="brand-copy">
          <h1>AI Shopping Assistant</h1>
          <p>Smart Mart indoor navigation</p>
        </div>
        <a className="open-link" href="/legacy/index.html" target="_blank" rel="noreferrer">
          Open in new tab ↗
        </a>
      </header>
      <section className="app-frame-wrap" aria-label="Shopping assistant application">
        <iframe title="AI Shopping Assistant app" src="/legacy/index.html" />
      </section>
      <footer>React + Vite launcher · Original shopping assistant preserved</footer>
    </main>
  )
}

@echo off
setlocal
title AI Shopping Assistant - React Launcher
cd /d "%~dp0"
echo.
echo ============================================
echo      AI SHOPPING ASSISTANT - REACT
echo ============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not on PATH.
  echo Install the LTS version from https://nodejs.org/
  echo Then close and reopen this window and run start.bat again.
  echo.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js LTS.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo First run: installing project dependencies...
  call npm install
  if errorlevel 1 (
    echo.
    echo Dependency installation failed. Check your internet connection.
    pause
    exit /b 1
  )
)

echo.
echo Starting development server...
echo Your browser should open at http://127.0.0.1:5173
echo Keep this window open while using the app.
echo Press Ctrl+C to stop the server.
echo.
start "" http://127.0.0.1:5173
call npm run dev
pause
